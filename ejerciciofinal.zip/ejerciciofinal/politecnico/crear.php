<?php include 'includes/redirect.php';?>
<?php require_once 'includes/header.php';?>
<?php
function mostrarError($error, $field){
  if(isset($error[$field]) && !empty($field)){
    $alerta='<div class="alert alert-danger">'.$error[$field].'</div>';
  }else{
    $alerta='';
  }
  return $alerta;
}
function setValueField($error,$field, $textarea=false){
  if(isset($error) && count($error)>=1 && isset($_POST[$field])){
    if($textarea != false){
      echo $_POST[$field];
    }else{
      echo "value='{$_POST[$field]}'";
    }
  }
}
$error=array();
if(isset($_POST["submit"])){

  if(!empty($_POST["num_id"])){
    $num_id_validador=true;
   }else{
   $num_id_validador=false;
    $error["num_id"]="Ingrese el Numero de Identificacion";
     }
 if(!empty($_POST["nombre"]) && strlen($_POST["nombre"]<=20) && !is_numeric($_POST["nombre"]) && !preg_match("/[0-9]/", $_POST["nombre"])){
$nombre_validador=true;
}else{
$nombre_validador=false;
$error["nombre"]="El nombre no es válido";
}
  if(!empty($_POST["apellidos"])&& !is_numeric($_POST["apellidos"]) && !preg_match("/[0-9]/", $_POST["apellidos"])){
      $apellidos_validador=true;
     }else{
     $apellidos_validador=false;
       $error["apellidos"]="Los apellidos no son válidos";
        }
        if(!empty($_POST["direccion"])){
       $direccion_validador=true;
      }else{
      $direccion_validador=false;
       $error["direccion"]="La direccion no puede estar vacía";
        }

        if(!empty($_POST["acudiente"]) && strlen($_POST["acudiente"]<=20) && !is_numeric($_POST["acudiente"]) && !preg_match("/[0-9]/", $_POST["acudiente"])){
       $acudiente_validador=true;
       }else{
       $acudiente_validador=false;
       $error["acudiente"]="Los nombres del acudiente no son válido";
       }
     if(!empty($_POST["tel_acudiente"]) && strlen($_POST["tel_acudiente"]>=6)){
       $tel_acudiente_validador=true;
      }else{
      $tel_acudiente_validador=false;
       $error["tel_acudiente"]="Introduzca un telefono valido";
        }

      //Crear una carpeta nuevo código
      $image=null;
      if(isset($_FILES["image"]) && !empty($_FILES["image"]["tmp_name"])){
        if(!is_dir("uploads")){
          $dir = mkdir("uploads", 0777, true);
        }else{
          $dir=true;
        }
        if($dir){
          $filename= time()."-".$_FILES["image"]["name"]; //concatenar función tiempo con el nombre de imagen
          $muf=move_uploaded_file($_FILES["image"]["tmp_name"], "uploads/".$filename); //mover el fichero utilizando esta función
          $image=$filename;
          if($muf){
            $image_upload=true;
          }else{
            $image_upload=false;
            $error["image"]= "La imagen no se ha subido";
          }
        }
        //var_dump($_FILES["image"]);
        //die();
	 	}
    //Insertar Usuarios en la base de Datos
    if(count($error)==0){
      $sql= "INSERT INTO estudiantes VALUES(NULL,'{$_POST["num_id"]}', '{$_POST["nombre"]}', '{$_POST["apellidos"]}','{$_POST["direccion"]}', '{$_POST["acudiente"]}','{$_POST["tel_acudiente"]}', '{$image}');"; //colocar image
      $insert_user=mysqli_query($db, $sql);
    }else{
      $insert_user=false;
    }
}
?>
<h1>Crear Estudiantes</h1>
<?php if(isset($_POST["submit"]) && count($error)==0 && $insert_user !=false){?>
  <div class="alert alert-success">
    El Estudiante se ha creado correctamente !!
  </div>
<?php } ?>
<form action="crear.php" method="POST" enctype="multipart/form-data">
  <label for="num_id">Identificacion:
  <input type="text" name="num_id" class="form-control" <?php setValueField($error, "num_id");?>/>
  <?php echo mostrarError($error, "num_id");?>
  </label>
  </br></br>
    <label for="nombre">Nombre:
    <input type="text" name="nombre" class="form-control" <?php setValueField($error, "nombre");?>/>
    <?php echo mostrarError($error, "nombre");?>
    </label>
    </br></br>
    <label for="apellidos">Apellidos:
        <input type="text" name="apellidos" class="form-control" <?php setValueField($error, "apellidos");?>/>
        <?php echo mostrarError($error, "apellidos");?>
    </label>
    </br></br>
      <label for="direccion">Direccion:
          <textarea name="direccion" class="form-control"><?php setValueField($error, "direccion", true);?></textarea>
          <?php echo mostrarError($error, "direccion");?>
      </label>
      </br></br>
      <label for="acudiente">Acudiente:
        <textarea name="acudiente" class="form-control"><?php setValueField($error, "acudiente", true);?></textarea>
        <?php echo mostrarError($error, "acudiente");?>
    </label>
    </br></br>
    <label for="tel_acudiente">Telefono Acudiente:
        <textarea name="tel_acudiente" class="form-control"><?php setValueField($error, "tel_acudiente", true);?></textarea>
        <?php echo mostrarError($error, "tel_acudiente");?>
    </label>
    </br></br>
    <label for="image">Imagen:
        <input type="file" name="image" class="form-control"/>
    </label>
    </br></br>
    <input type="submit" value="Enviar" name="submit" class="btn btn-warning"/>
</form>
<?php require_once 'includes/footer.php'; ?>
