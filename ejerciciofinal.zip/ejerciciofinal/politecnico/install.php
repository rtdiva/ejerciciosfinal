<?php
require_once 'includes/connect.php';

$sql = "CREATE TABLE IF NOT EXISTS estudiantes(
			id  int(255) auto_increment not null,
			num_id	 varchar(50),
			nombre	 varchar(50),
			apellidos  varchar(255),
			direccion   varchar(255),
			acudiente   varchar(255),
			tel_acudiente	  varchar(20),
			image	   varchar(255),
			CONSTRAINT pk_estudiantes PRIMARY KEY(id)
		);";

$create_estudiantes_table = mysqli_query($db, $sql);
$sql = "INSERT INTO estudiantes VALUES(NULL, '162728229', 'yuli', 'peralta', 'carrera 13 n°4-14', 'maria vargas', '3267895432', NULL)";
$insert_estudiante = mysqli_query($db, $sql);

$sql = "INSERT INTO estudiantes VALUES(NULL, '627823', 'lina', 'rivera','carrera 18 n°11-90', 'ramiro rivera', '23445262', NULL)";
$insert_estudiante1 = mysqli_query($db, $sql);

$sql = "INSERT INTO estudiantes VALUES(NULL, '647438329', 'stiven', 'lopez', 'calle 5  n°3-21', 'camila blanco', '3212345678', NULL)";
$insert_estudiante2= mysqli_query($db, $sql);

$sql = "INSERT INTO estudiantes VALUES(NULL, '6473829', 'valentina', 'alvira', 'calle 3 n°9-25', 'luisa nieto', '3154562300', NULL)";
$insert_estudiante3 = mysqli_query($db, $sql);



if($create_estudiantes_table){
	echo "La tabla estudiantes se ha creado correctamente !!";
}
?>
