<?php
// nuevo codigo
$db = new mysqli("localhost", "root", "", "politecnico");
mysqli_query($db, "SET NAMES 'utf8'");
?>
