<hr/>
<footer>
&copy; ADSI <?php echo date("Y");?>
</footer>
</div>
</body>
</html>