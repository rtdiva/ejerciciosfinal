<?php
// nuevo codigo
$db = new mysqli("localhost", "root", "", "banda");
mysqli_query($db, "SET NAMES 'utf8'");
?>
