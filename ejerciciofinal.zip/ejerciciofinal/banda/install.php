<?php
require_once 'includes/connect.php';

$sql = "CREATE TABLE IF NOT EXISTS estudiantes(
			id  int(255) auto_increment not null,
			num_id	 varchar(50),
			nombre	 varchar(50),
			apellidos  varchar(255),
			instrumento	  varchar(255),
			direccion   varchar(255),
			acudiente   varchar(255),
			tel_acudiente	  varchar(20),
			image	   varchar(255),
			CONSTRAINT pk_estudiantes PRIMARY KEY(id)
		);";

$create_estudiantes_table = mysqli_query($db, $sql);
$sql = "INSERT INTO estudiantes VALUES(NULL, '122345565', 'paquito', 'perez', '1', 'carrera 13 n°4-14', 'luna perez', '3267895432', NULL)";
$insert_estudiante = mysqli_query($db, $sql);

$sql = "INSERT INTO estudiantes VALUES(NULL, '1098765434', 'laura', 'marquez', '1', 'carrera 18 n°11-90', 'maria ruiz', '23445262', NULL)";
$insert_estudiante1 = mysqli_query($db, $sql);

$sql = "INSERT INTO estudiantes VALUES(NULL, '153758990', 'stiven', 'lopez', '1', 'calle 5  n°3-21', 'fredy lopez', '3212345678', NULL)";
$insert_estudiante2= mysqli_query($db, $sql);

$sql = "INSERT INTO estudiantes VALUES(NULL, '23456787', 'sofia', 'bernal', '1', 'calle 3 n°9-25', 'karina bernal', '3154562300', NULL)";
$insert_estudiante3 = mysqli_query($db, $sql);

//hola mundo

if($create_estudiantes_table){
	echo "La tabla estudiantes se ha creado correctamente !!";
}
?>

