<?php include 'includes/header.php';?>
<?php
session_star();
if(isset($_POST["submit"])){
  $nombre=trim($_POST["nombre"]));
  $identificacion=sha1($_POST["num_id"]));
  $sql="SELECT *FROM estudiantes WHERE nombre='diva' and num_id='1055274282';
  $login=mysqli_query ($db,$sql);
  if($login && mysqli_num_rows($login)==1){

}
}
