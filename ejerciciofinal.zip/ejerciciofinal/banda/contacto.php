<?php include("includes/header.php")?>
<p>Contáctanos</p>
<form method="post" action="">
<input type="text" name="nombre"/>
<input type="email" name="email"/>
<input type="submit" name="Enviar"/>
</form>
<?php include("includes/footer.php")?>